import cProfile as time_profile
import pstats
from memory_profiler import profile as memory_profile
