# How to create new file

-   For adding new code first improt `setup.py` and `profiling.py` (if profiling needed)
-   Make sure to make code inside `Experiments` folder.

# How to run

-   run `python3 -m venv ./venv` to create new environment
-   run `pip install -r requirements.txt`
-   run `python3 <filename>.py`
